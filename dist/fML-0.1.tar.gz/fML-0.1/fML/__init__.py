from fastML import fastML
from fastML import EncodeCategorical
from nnclassifier import neuralnet